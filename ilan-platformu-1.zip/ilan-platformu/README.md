# İlan Platformu

Next.js + Supabase + iyzico ile geliştirilmiş, gerçek zamanlı mesajlaşma destekli ilan platformu.

## Hızlı Kurulum

1. Bu repo'yu Vercel'e bağlayın.
2. Supabase projesi oluşturun, `supabase/migrations/` klasöründeki SQL dosyalarını sırayla (0001, 0002) SQL Editor'de çalıştırın.
3. Supabase Storage'da `listing-images` adında **public** bir bucket oluşturun.
4. `.env.local.example` dosyasındaki tüm değişkenleri Vercel'in Environment Variables kısmına ekleyin.
5. Vercel'de "Deploy" butonuna basın.

## Önemli Notlar

- `SUPABASE_SERVICE_ROLE_KEY` asla `NEXT_PUBLIC_` öneki almamalı — bu key sadece sunucu tarafında kullanılır.
- iyzico sandbox bilgileriyle test edip, canlıya almadan önce production API key'lerine geçin.
- PWA ikonları (`public/icons/`) şu an placeholder'dır — gerçek logo ile değiştirilmesi önerilir.

Detaylı kurulum rehberi için sohbet geçmişine bakın.
