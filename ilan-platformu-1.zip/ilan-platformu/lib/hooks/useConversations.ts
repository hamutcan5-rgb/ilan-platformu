'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';

export interface ConversationListItem {
  id: string;
  listing_id: string | null;
  buyer_id: string;
  seller_id: string;
  last_message_at: string;
  listing_title?: string;
  other_user_name?: string;
  unread_count: number;
}

export function useConversations(currentUserId: string) {
  const [conversations, setConversations] = useState<ConversationListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    async function fetchConversations() {
      setLoading(true);

      const { data, error } = await supabase
        .from('conversations')
        .select(
          `
          id, listing_id, buyer_id, seller_id, last_message_at,
          listings ( title ),
          buyer:profiles!conversations_buyer_id_fkey ( full_name ),
          seller:profiles!conversations_seller_id_fkey ( full_name )
        `
        )
        .or(`buyer_id.eq.${currentUserId},seller_id.eq.${currentUserId}`)
        .order('last_message_at', { ascending: false });

      if (!error && data) {
        const enriched = await Promise.all(
          data.map(async (conv: any) => {
            const { count } = await supabase
              .from('messages')
              .select('id', { count: 'exact', head: true })
              .eq('conversation_id', conv.id)
              .eq('is_read', false)
              .neq('sender_id', currentUserId);

            const isCurrentUserBuyer = conv.buyer_id === currentUserId;

            return {
              id: conv.id,
              listing_id: conv.listing_id,
              buyer_id: conv.buyer_id,
              seller_id: conv.seller_id,
              last_message_at: conv.last_message_at,
              listing_title: conv.listings?.title,
              other_user_name: isCurrentUserBuyer
                ? conv.seller?.full_name
                : conv.buyer?.full_name,
              unread_count: count || 0,
            };
          })
        );
        setConversations(enriched);
      }

      setLoading(false);
    }

    fetchConversations();

    const channel = supabase
      .channel('conversations-list')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        () => fetchConversations()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUserId]);

  return { conversations, loading };
}
