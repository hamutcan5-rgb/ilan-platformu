'use client';

import { useCallback, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';

export function useStartConversation() {
  const [loading, setLoading] = useState(false);
  const supabase = createClient();
  const router = useRouter();

  const startConversation = useCallback(
    async (listingId: string, sellerId: string, buyerId: string) => {
      if (sellerId === buyerId) {
        return { error: 'Kendi ilanınıza mesaj gönderemezsiniz.' };
      }

      setLoading(true);

      const { data: existing } = await supabase
        .from('conversations')
        .select('id')
        .eq('listing_id', listingId)
        .eq('buyer_id', buyerId)
        .eq('seller_id', sellerId)
        .maybeSingle();

      if (existing) {
        setLoading(false);
        router.push(`/mesajlar/${existing.id}`);
        return { error: null };
      }

      const { data, error } = await supabase
        .from('conversations')
        .insert({ listing_id: listingId, buyer_id: buyerId, seller_id: sellerId })
        .select('id')
        .single();

      setLoading(false);

      if (error) {
        return { error: error.message };
      }

      router.push(`/mesajlar/${data.id}`);
      return { error: null };
    },
    [supabase, router]
  );

  return { startConversation, loading };
}
