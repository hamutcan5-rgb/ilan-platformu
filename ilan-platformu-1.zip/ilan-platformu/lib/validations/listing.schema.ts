import { z } from 'zod';

export const listingSchema = z.object({
  category_id: z.string().uuid({ message: 'Lütfen bir kategori seçin.' }),
  title: z
    .string()
    .min(10, 'Başlık en az 10 karakter olmalı.')
    .max(100, 'Başlık en fazla 100 karakter olabilir.'),
  description: z
    .string()
    .min(20, 'Açıklama en az 20 karakter olmalı.')
    .max(2000, 'Açıklama en fazla 2000 karakter olabilir.'),
  price: z.coerce.number().min(1, 'Geçerli bir fiyat girin.'),
  city: z.string().min(1, 'Şehir seçin.'),
  district: z.string().min(1, 'İlçe seçin.'),
});

export type ListingFormValues = z.infer<typeof listingSchema>;
