import Iyzipay from 'iyzipay';

export const iyzico = new Iyzipay({
  apiKey: process.env.IYZICO_API_KEY!,
  secretKey: process.env.IYZICO_SECRET_KEY!,
  uri: process.env.IYZICO_BASE_URL || 'https://sandbox-api.iyzipay.com',
});

export const LISTING_FEE = 50.0;
export const CURRENCY = 'TRY';

export interface CheckoutFormParams {
  conversationId: string;
  price: number;
  userId: string;
  userEmail: string;
  userName: string;
  userPhone: string;
  callbackUrl: string;
  ip: string;
}

/**
 * iyzico "Checkout Form" akışını başlatır.
 * Kart bilgileri bizim sunucumuzdan asla geçmez (PCI-DSS yükü iyzico'da kalır).
 */
export function createCheckoutFormRequest(params: CheckoutFormParams) {
  return new Promise<any>((resolve, reject) => {
    const request = {
      locale: 'tr',
      conversationId: params.conversationId,
      price: params.price.toFixed(2),
      paidPrice: params.price.toFixed(2),
      currency: CURRENCY,
      basketId: params.conversationId,
      paymentGroup: 'PRODUCT',
      callbackUrl: params.callbackUrl,
      buyer: {
        id: params.userId,
        name: params.userName || 'Kullanici',
        surname: '-',
        gsmNumber: params.userPhone || '+905000000000',
        email: params.userEmail,
        identityNumber: '11111111111',
        registrationAddress: 'Belirtilmedi',
        ip: params.ip,
        city: 'Istanbul',
        country: 'Turkey',
      },
      shippingAddress: {
        contactName: params.userName || 'Kullanici',
        city: 'Istanbul',
        country: 'Turkey',
        address: 'Dijital urun - kargo yok',
      },
      billingAddress: {
        contactName: params.userName || 'Kullanici',
        city: 'Istanbul',
        country: 'Turkey',
        address: 'Dijital urun - kargo yok',
      },
      basketItems: [
        {
          id: 'listing-fee',
          name: 'Ilan Yayinlama Ucreti',
          category1: 'Hizmet',
          itemType: 'VIRTUAL',
          price: params.price.toFixed(2),
        },
      ],
    };

    iyzico.checkoutFormInitialize.create(request, (err: any, result: any) => {
      if (err) return reject(err);
      resolve(result);
    });
  });
}

export function retrieveCheckoutForm(token: string) {
  return new Promise<any>((resolve, reject) => {
    iyzico.checkoutForm.retrieve({ locale: 'tr', token }, (err: any, result: any) => {
      if (err) return reject(err);
      resolve(result);
    });
  });
}
