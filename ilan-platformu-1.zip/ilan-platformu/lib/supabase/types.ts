// Bu dosya Supabase CLI ile otomatik üretilebilir:
//   npx supabase gen types typescript --project-id <PROJECT_REF> > lib/supabase/types.ts
// Şimdilik generic bir tip bırakıyoruz; CLI çalıştırınca üzerine yazılacak.

export type Database = any;
