import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { createCheckoutFormRequest, LISTING_FEE } from '@/lib/payments/iyzico';

export async function POST(request: NextRequest) {
  const supabase = await createClient();
  const { data: { user }, error: authError } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: 'Yetkisiz istek.' }, { status: 401 });
  }

  const body = await request.json();
  const { listingId } = body;

  if (!listingId) {
    return NextResponse.json({ error: 'listingId zorunludur.' }, { status: 400 });
  }

  const { data: listing, error: listingError } = await supabase
    .from('listings')
    .select('id, user_id, status')
    .eq('id', listingId)
    .single();

  if (listingError || !listing || listing.user_id !== user.id) {
    return NextResponse.json({ error: 'İlan bulunamadı veya yetkiniz yok.' }, { status: 403 });
  }

  if (listing.status !== 'draft' && listing.status !== 'pending_payment') {
    return NextResponse.json({ error: 'Bu ilan için ödeme zaten tamamlanmış.' }, { status: 409 });
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('full_name, phone')
    .eq('id', user.id)
    .single();

  const ip = request.headers.get('x-forwarded-for')?.split(',')[0] || '127.0.0.1';

  try {
    const checkoutResult = await createCheckoutFormRequest({
      conversationId: listingId,
      price: LISTING_FEE,
      userId: user.id,
      userEmail: user.email || '',
      userName: profile?.full_name || 'Kullanici',
      userPhone: profile?.phone || '',
      callbackUrl: `${process.env.NEXT_PUBLIC_SITE_URL}/api/payments/webhook`,
      ip,
    });

    if (checkoutResult.status !== 'success') {
      return NextResponse.json(
        { error: checkoutResult.errorMessage || 'Ödeme başlatılamadı.' },
        { status: 400 }
      );
    }

    const admin = createAdminClient();

    await admin.from('payments').insert({
      user_id: user.id,
      listing_id: listingId,
      amount: LISTING_FEE,
      status: 'pending',
      provider: 'iyzico',
      provider_payment_id: checkoutResult.token,
      raw_response: checkoutResult,
    });

    await admin
      .from('listings')
      .update({ status: 'pending_payment' })
      .eq('id', listingId);

    return NextResponse.json({
      checkoutFormContent: checkoutResult.checkoutFormContent,
      token: checkoutResult.token,
      paymentPageUrl: checkoutResult.paymentPageUrl,
    });
  } catch (err) {
    console.error('iyzico checkout error:', err);
    return NextResponse.json({ error: 'Ödeme servisi şu anda kullanılamıyor.' }, { status: 502 });
  }
}
