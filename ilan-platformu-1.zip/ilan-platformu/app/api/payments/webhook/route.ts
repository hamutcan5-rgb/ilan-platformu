import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { retrieveCheckoutForm } from '@/lib/payments/iyzico';

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const token = formData.get('token') as string | null;

  if (!token) {
    return NextResponse.json({ error: 'Token eksik.' }, { status: 400 });
  }

  const admin = createAdminClient();

  try {
    // KRİTİK: Ödeme durumu asla client'tan veya callback body'sinden güvenilmez.
    const result = await retrieveCheckoutForm(token);

    const { data: paymentRecord } = await admin
      .from('payments')
      .select('id, listing_id, status')
      .eq('provider_payment_id', token)
      .single();

    if (!paymentRecord) {
      console.error('Webhook: eşleşen ödeme kaydı bulunamadı, token:', token);
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_SITE_URL}/ilan/yeni?status=error`
      );
    }

    if (paymentRecord.status === 'success') {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_SITE_URL}/ilan/${paymentRecord.listing_id}?status=already_active`
      );
    }

    const isSuccess = result.status === 'success' && result.paymentStatus === 'SUCCESS';

    await admin
      .from('payments')
      .update({
        status: isSuccess ? 'success' : 'failed',
        raw_response: result,
        updated_at: new Date().toISOString(),
      })
      .eq('id', paymentRecord.id);

    if (isSuccess && paymentRecord.listing_id) {
      const { error: activationError } = await admin
        .from('listings')
        .update({
          status: 'active',
          expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        })
        .eq('id', paymentRecord.listing_id);

      if (activationError) {
        console.error('İlan aktivasyon hatası:', activationError);
      }

      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_SITE_URL}/ilan/${paymentRecord.listing_id}?status=success`
      );
    }

    if (paymentRecord.listing_id) {
      await admin
        .from('listings')
        .update({ status: 'draft' })
        .eq('id', paymentRecord.listing_id);
    }

    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_SITE_URL}/ilan/yeni?status=failed`
    );
  } catch (err) {
    console.error('iyzico webhook error:', err);
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_SITE_URL}/ilan/yeni?status=error`
    );
  }
}
