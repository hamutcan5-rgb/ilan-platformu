import { ListingGrid } from '@/components/listings/ListingGrid';
import { ListingFilters } from '@/components/listings/ListingFilters';
import { createClient } from '@/lib/supabase/server';

export default async function HomePage() {
  const supabase = await createClient();

  const { data: categories } = await supabase.from('categories').select('id, name').order('sort_order');

  const { data: listings } = await supabase
    .from('listings')
    .select(`
      id, title, price, currency, city, district, created_at, is_featured,
      listing_images ( storage_path, sort_order )
    `)
    .eq('status', 'active')
    .order('created_at', { ascending: false })
    .limit(40);

  const listingCards = (listings || []).map((l: any) => ({
    id: l.id,
    title: l.title,
    price: l.price,
    currency: l.currency,
    city: l.city,
    district: l.district,
    created_at: l.created_at,
    is_featured: l.is_featured,
    cover_image_url: l.listing_images?.[0]?.storage_path
      ? `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/listing-images/${l.listing_images[0].storage_path}`
      : null,
  }));

  return (
    <div className="mx-auto flex max-w-7xl gap-6 px-4 py-6 sm:px-6 lg:px-8">
      <ListingFilters categories={categories || []} onApply={() => {}} />
      <div className="flex-1">
        <ListingGrid listings={listingCards} />
      </div>
    </div>
  );
}
