import { notFound } from 'next/navigation';
import Image from 'next/image';
import { MapPin } from 'lucide-react';
import { createClient } from '@/lib/supabase/server';
import { formatPrice, formatRelativeTime } from '@/lib/utils';
import { StartChatButton } from '@/components/listings/StartChatButton';

export default async function ListingDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: listing } = await supabase
    .from('listings')
    .select(`
      id, title, description, price, currency, city, district, created_at, user_id,
      listing_images ( storage_path, sort_order ),
      profiles ( id, full_name )
    `)
    .eq('id', id)
    .eq('status', 'active')
    .single();

  if (!listing) {
    notFound();
  }

  const { data: { user } } = await supabase.auth.getUser();
  const images = (listing.listing_images || []).sort((a: any, b: any) => a.sort_order - b.sort_order);
  const seller = listing.profiles as any;

  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <div className="grid gap-6 sm:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-2xl bg-slate-100">
          {images[0] ? (
            <Image
              src={`${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/listing-images/${images[0].storage_path}`}
              alt={listing.title}
              fill
              className="object-cover"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-slate-300">Görsel yok</div>
          )}
        </div>

        <div>
          <h1 className="text-xl font-semibold text-slate-900">{listing.title}</h1>
          <p className="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900">
            {formatPrice(listing.price, listing.currency)}
          </p>
          <div className="mt-2 flex items-center gap-1.5 text-sm text-slate-500">
            <MapPin className="h-4 w-4" />
            {listing.district}, {listing.city}
            <span className="mx-1">·</span>
            {formatRelativeTime(listing.created_at)}
          </div>

          <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-slate-700">
            {listing.description}
          </p>

          <div className="mt-6 rounded-xl border border-slate-100 p-4">
            <p className="text-sm font-medium text-slate-900">{seller?.full_name}</p>
            {user && user.id !== listing.user_id && (
              <StartChatButton listingId={listing.id} sellerId={listing.user_id} buyerId={user.id} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
