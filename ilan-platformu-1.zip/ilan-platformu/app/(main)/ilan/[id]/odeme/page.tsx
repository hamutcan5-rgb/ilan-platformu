'use client';

import { useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';

export default function PaymentPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useEffect(() => {
    const content = sessionStorage.getItem('iyzico_checkout_content');
    if (!content) {
      router.replace('/ilan/yeni');
      return;
    }

    if (containerRef.current) {
      containerRef.current.innerHTML = content;
      const scripts = containerRef.current.querySelectorAll('script');
      scripts.forEach((oldScript) => {
        const newScript = document.createElement('script');
        Array.from(oldScript.attributes).forEach((attr) =>
          newScript.setAttribute(attr.name, attr.value)
        );
        newScript.textContent = oldScript.textContent;
        oldScript.parentNode?.replaceChild(newScript, oldScript);
      });
    }

    sessionStorage.removeItem('iyzico_checkout_content');
  }, [router]);

  return (
    <div className="mx-auto max-w-lg px-4 py-10">
      <h1 className="mb-1 text-lg font-semibold text-slate-900">Ödeme</h1>
      <p className="mb-6 text-sm text-slate-500">
        İlanınızın yayınlanması için 50 ₺ ödeme adımını tamamlayın.
      </p>
      <div ref={containerRef} id="iyzipay-checkout-form" className="rounded-2xl ring-1 ring-slate-100 p-1" />
    </div>
  );
}
