import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { ListingForm } from '@/components/listings/ListingForm';

export default async function NewListingPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { data: categories } = await supabase.from('categories').select('id, name').order('sort_order');

  return (
    <div className="px-4 py-8">
      <ListingForm categories={categories || []} userId={user.id} />
    </div>
  );
}
