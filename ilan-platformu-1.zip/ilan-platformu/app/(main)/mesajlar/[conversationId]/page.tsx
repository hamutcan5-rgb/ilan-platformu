import { notFound, redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { ChatWindow } from '@/components/chat/ChatWindow';

export default async function ConversationPage({
  params,
}: {
  params: Promise<{ conversationId: string }>;
}) {
  const { conversationId } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { data: conversation } = await supabase
    .from('conversations')
    .select(`
      id, buyer_id, seller_id,
      listing:listings ( id, title, price ),
      buyer:profiles!conversations_buyer_id_fkey ( id, full_name, avatar_url ),
      seller:profiles!conversations_seller_id_fkey ( id, full_name, avatar_url )
    `)
    .eq('id', conversationId)
    .single();

  if (!conversation || (conversation.buyer_id !== user.id && conversation.seller_id !== user.id)) {
    notFound();
  }

  const isBuyer = conversation.buyer_id === user.id;
  const otherUser = isBuyer ? (conversation.seller as any) : (conversation.buyer as any);
  const listing = conversation.listing as any;

  return (
    <ChatWindow
      conversationId={conversation.id}
      currentUserId={user.id}
      otherUser={{ name: otherUser?.full_name || 'Kullanıcı', avatarUrl: otherUser?.avatar_url || null }}
      listing={listing}
    />
  );
}
