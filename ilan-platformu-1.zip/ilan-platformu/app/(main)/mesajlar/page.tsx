import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { ConversationListClient } from '@/components/chat/ConversationListClient';

export default async function MessagesPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="px-4 py-4 text-lg font-semibold text-slate-900">Mesajlar</h1>
      <ConversationListClient currentUserId={user.id} />
    </div>
  );
}
