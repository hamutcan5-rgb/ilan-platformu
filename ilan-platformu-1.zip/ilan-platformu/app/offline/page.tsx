export default function OfflinePage() {
  return (
    <div className="flex h-screen flex-col items-center justify-center gap-2 px-6 text-center">
      <p className="text-lg font-semibold text-slate-900">Bağlantı yok</p>
      <p className="text-sm text-slate-500">
        İnternet bağlantınızı kontrol edip tekrar deneyin. Mesajlar bağlantı geldiğinde senkronize olur.
      </p>
    </div>
  );
}
