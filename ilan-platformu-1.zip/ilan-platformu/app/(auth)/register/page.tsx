'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { createClient } from '@/lib/supabase/client';

export default function RegisterPage() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName },
      },
    });

    if (signUpError) {
      setLoading(false);
      setError(
        signUpError.message === 'User already registered'
          ? 'Bu e-posta adresi zaten kayıtlı.'
          : signUpError.message
      );
      return;
    }

    // profiles tablosuna kayıt oluştur (auth.users tetikleyicisi yoksa burada elle yapılır)
    if (data.user) {
      await supabase.from('profiles').insert({
        id: data.user.id,
        full_name: fullName,
      });
    }

    setLoading(false);

    // E-posta doğrulaması açıksa kullanıcı hemen oturum açamaz
    if (!data.session) {
      setSuccess(true);
      return;
    }

    router.push('/');
    router.refresh();
  }

  if (success) {
    return (
      <div className="text-center">
        <h1 className="text-xl font-semibold text-slate-900">E-postanızı kontrol edin</h1>
        <p className="mt-2 text-sm text-slate-500">
          Hesabınızı onaylamak için size gönderdiğimiz bağlantıya tıklayın.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">Üye Ol</h1>
        <p className="mt-1 text-sm text-slate-500">Ücretsiz hesap oluşturun, hemen ilan vermeye başlayın.</p>
      </div>

      <Input
        label="Ad Soyad"
        type="text"
        autoComplete="name"
        value={fullName}
        onChange={(e) => setFullName(e.target.value)}
        required
      />
      <Input
        label="E-posta"
        type="email"
        autoComplete="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <Input
        label="Şifre"
        type="password"
        autoComplete="new-password"
        minLength={6}
        hint="En az 6 karakter"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />

      {error && <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

      <Button type="submit" className="w-full" isLoading={loading}>
        Üye Ol
      </Button>

      <p className="text-center text-sm text-slate-500">
        Zaten hesabınız var mı?{' '}
        <Link href="/login" className="font-medium text-slate-900">
          Giriş yapın
        </Link>
      </p>
    </form>
  );
}
