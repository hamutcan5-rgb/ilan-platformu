-- ============================================
-- 0002_rls_policies.sql
-- ============================================

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_images enable row level security;
alter table public.payments enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.favorites enable row level security;

-- PROFILES
create policy "Profiles are publicly viewable"
  on public.profiles for select using (true);

create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);

-- LISTINGS
create policy "Active listings are publicly viewable"
  on public.listings for select
  using (status = 'active' or auth.uid() = user_id);

create policy "Users can insert own listings"
  on public.listings for insert
  with check (auth.uid() = user_id);

create policy "Users can update own listings"
  on public.listings for update
  using (auth.uid() = user_id);

create policy "Users can delete own listings"
  on public.listings for delete
  using (auth.uid() = user_id);

-- LISTING IMAGES
create policy "Listing images viewable with listing"
  on public.listing_images for select using (true);

create policy "Owners manage own listing images"
  on public.listing_images for all
  using (
    exists (
      select 1 from public.listings
      where listings.id = listing_images.listing_id
      and listings.user_id = auth.uid()
    )
  );

-- PAYMENTS (kullanıcı sadece kendi ödemesini görür, INSERT sadece server-side/service role)
create policy "Users view own payments"
  on public.payments for select using (auth.uid() = user_id);

-- CONVERSATIONS
create policy "Participants view own conversations"
  on public.conversations for select
  using (auth.uid() = buyer_id or auth.uid() = seller_id);

create policy "Buyers can start conversations"
  on public.conversations for insert
  with check (auth.uid() = buyer_id);

-- MESSAGES
create policy "Participants view messages"
  on public.messages for select
  using (
    exists (
      select 1 from public.conversations c
      where c.id = messages.conversation_id
      and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())
    )
  );

create policy "Participants send messages"
  on public.messages for insert
  with check (
    auth.uid() = sender_id
    and exists (
      select 1 from public.conversations c
      where c.id = messages.conversation_id
      and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())
    )
  );

-- FAVORITES
create policy "Users manage own favorites"
  on public.favorites for all using (auth.uid() = user_id);
