-- ============================================
-- 0001_init_schema.sql
-- ============================================

create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm";

-- ============================================
-- PROFILES (auth.users genişletmesi)
-- ============================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  avatar_url text,
  city text,
  district text,
  is_verified boolean default false,
  rating_avg numeric(3,2) default 0,
  rating_count integer default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_profiles_city on public.profiles(city);

-- ============================================
-- CATEGORIES
-- ============================================
create table public.categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique not null,
  parent_id uuid references public.categories(id) on delete set null,
  icon text,
  sort_order integer default 0,
  created_at timestamptz default now()
);

-- ============================================
-- LISTINGS (İlanlar)
-- ============================================
create type listing_status as enum ('draft', 'pending_payment', 'active', 'sold', 'expired', 'rejected');

create table public.listings (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category_id uuid not null references public.categories(id),
  title text not null,
  description text not null,
  price numeric(12,2) not null check (price >= 0),
  currency text default 'TRY',
  city text not null,
  district text not null,
  status listing_status default 'draft',
  view_count integer default 0,
  is_featured boolean default false,
  search_vector tsvector,
  expires_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_listings_status on public.listings(status);
create index idx_listings_category on public.listings(category_id);
create index idx_listings_city on public.listings(city);
create index idx_listings_user on public.listings(user_id);
create index idx_listings_search on public.listings using gin(search_vector);
create index idx_listings_created on public.listings(created_at desc);

create or replace function update_listing_search_vector()
returns trigger as $$
begin
  new.search_vector :=
    to_tsvector('turkish', coalesce(new.title, '') || ' ' || coalesce(new.description, ''));
  return new;
end;
$$ language plpgsql;

create trigger trg_listing_search_vector
before insert or update on public.listings
for each row execute function update_listing_search_vector();

-- ============================================
-- LISTING IMAGES
-- ============================================
create table public.listing_images (
  id uuid primary key default uuid_generate_v4(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  storage_path text not null,
  sort_order integer default 0,
  created_at timestamptz default now()
);

create index idx_listing_images_listing on public.listing_images(listing_id);

-- ============================================
-- PAYMENTS (50 TL ilan ücreti kontrolü)
-- ============================================
create type payment_status as enum ('pending', 'success', 'failed', 'refunded');

create table public.payments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete set null,
  amount numeric(10,2) not null default 50.00,
  currency text default 'TRY',
  status payment_status default 'pending',
  provider text not null default 'iyzico',
  provider_payment_id text unique,
  raw_response jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_payments_user on public.payments(user_id);
create index idx_payments_listing on public.payments(listing_id);
create index idx_payments_provider_id on public.payments(provider_payment_id);

create or replace function check_listing_payment()
returns trigger as $$
begin
  if new.status = 'active' and old.status = 'draft' then
    if not exists (
      select 1 from public.payments
      where listing_id = new.id and status = 'success'
    ) then
      raise exception 'Listing cannot be activated without a successful payment';
    end if;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_check_listing_payment
before update on public.listings
for each row execute function check_listing_payment();

-- ============================================
-- CONVERSATIONS (Sohbetler)
-- ============================================
create table public.conversations (
  id uuid primary key default uuid_generate_v4(),
  listing_id uuid references public.listings(id) on delete set null,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  last_message_at timestamptz default now(),
  created_at timestamptz default now(),
  unique (listing_id, buyer_id, seller_id)
);

create index idx_conversations_buyer on public.conversations(buyer_id);
create index idx_conversations_seller on public.conversations(seller_id);
create index idx_conversations_last_msg on public.conversations(last_message_at desc);

-- ============================================
-- MESSAGES (Real-time Chat)
-- ============================================
create table public.messages (
  id uuid primary key default uuid_generate_v4(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  is_read boolean default false,
  created_at timestamptz default now()
);

create index idx_messages_conversation on public.messages(conversation_id, created_at);
create index idx_messages_unread on public.messages(conversation_id) where is_read = false;

create or replace function update_conversation_last_message()
returns trigger as $$
begin
  update public.conversations
  set last_message_at = new.created_at
  where id = new.conversation_id;
  return new;
end;
$$ language plpgsql;

create trigger trg_update_conversation_last_message
after insert on public.messages
for each row execute function update_conversation_last_message();

-- ============================================
-- FAVORITES
-- ============================================
create table public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, listing_id)
);

alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.conversations;
