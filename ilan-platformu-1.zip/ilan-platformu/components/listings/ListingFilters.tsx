'use client';

import { useState } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';

interface CategoryOption {
  id: string;
  name: string;
}

interface ListingFiltersProps {
  categories: CategoryOption[];
  onApply: (filters: { categoryId?: string; minPrice?: number; maxPrice?: number; city?: string }) => void;
}

function FilterFields({ categories, onApply, onDone }: ListingFiltersProps & { onDone?: () => void }) {
  const [categoryId, setCategoryId] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [city, setCity] = useState('');

  function apply() {
    onApply({
      categoryId: categoryId || undefined,
      minPrice: minPrice ? Number(minPrice) : undefined,
      maxPrice: maxPrice ? Number(maxPrice) : undefined,
      city: city || undefined,
    });
    onDone?.();
  }

  return (
    <div className="space-y-5">
      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">Kategori</label>
        <select
          value={categoryId}
          onChange={(e) => setCategoryId(e.target.value)}
          className="h-11 w-full rounded-lg border border-slate-200 bg-white px-3.5 text-sm focus:border-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
        >
          <option value="">Tümü</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Input label="Min. Fiyat" type="number" placeholder="0" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} />
        <Input label="Maks. Fiyat" type="number" placeholder="∞" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} />
      </div>

      <Input label="Şehir" placeholder="İstanbul" value={city} onChange={(e) => setCity(e.target.value)} />

      <Button onClick={apply} className="w-full">Filtreleri Uygula</Button>
    </div>
  );
}

export function ListingFilters(props: ListingFiltersProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <aside className="hidden w-64 shrink-0 lg:block">
        <div className="sticky top-24 rounded-2xl border border-slate-100 p-5">
          <h3 className="mb-4 text-sm font-semibold text-slate-900">Filtrele</h3>
          <FilterFields {...props} />
        </div>
      </aside>

      <button
        onClick={() => setIsOpen(true)}
        className="mb-4 flex items-center gap-2 self-start rounded-full border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 lg:hidden"
      >
        <SlidersHorizontal className="h-4 w-4" />
        Filtrele
      </button>

      <Modal isOpen={isOpen} onClose={() => setIsOpen(false)} title="Filtrele">
        <FilterFields {...props} onDone={() => setIsOpen(false)} />
      </Modal>
    </>
  );
}
