'use client';

import { Button } from '@/components/ui/Button';
import { useStartConversation } from '@/lib/hooks/useStartConversation';

interface StartChatButtonProps {
  listingId: string;
  sellerId: string;
  buyerId: string;
}

export function StartChatButton({ listingId, sellerId, buyerId }: StartChatButtonProps) {
  const { startConversation, loading } = useStartConversation();

  return (
    <Button
      className="mt-3 w-full"
      isLoading={loading}
      onClick={() => startConversation(listingId, sellerId, buyerId)}
    >
      Satıcıya Mesaj Gönder
    </Button>
  );
}
