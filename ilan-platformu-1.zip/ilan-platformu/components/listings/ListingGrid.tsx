import { ListingCard, ListingCardData } from './ListingCard';

interface ListingGridProps {
  listings: ListingCardData[];
  favoritedIds?: Set<string>;
  onToggleFavorite?: (listingId: string) => void;
  isLoading?: boolean;
}

export function ListingGrid({ listings, favoritedIds, onToggleFavorite, isLoading }: ListingGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="overflow-hidden rounded-2xl bg-white ring-1 ring-slate-100">
            <div className="aspect-[4/3] animate-pulse bg-slate-100" />
            <div className="space-y-2 p-3.5">
              <div className="h-3.5 w-full animate-pulse rounded bg-slate-100" />
              <div className="h-3 w-2/3 animate-pulse rounded bg-slate-100" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (listings.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 py-20 text-center">
        <p className="text-sm font-medium text-slate-700">Sonuç bulunamadı</p>
        <p className="mt-1 text-sm text-slate-500">Farklı bir arama veya filtre deneyin.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {listings.map((listing) => (
        <ListingCard
          key={listing.id}
          listing={listing}
          isFavorited={favoritedIds?.has(listing.id)}
          onToggleFavorite={onToggleFavorite}
        />
      ))}
    </div>
  );
}
