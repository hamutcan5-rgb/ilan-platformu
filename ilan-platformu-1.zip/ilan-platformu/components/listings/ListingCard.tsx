import Link from 'next/link';
import Image from 'next/image';
import { Heart, MapPin } from 'lucide-react';
import { formatPrice, formatRelativeTime } from '@/lib/utils';

export interface ListingCardData {
  id: string;
  title: string;
  price: number;
  currency: string;
  city: string;
  district: string;
  created_at: string;
  is_featured: boolean;
  cover_image_url: string | null;
}

interface ListingCardProps {
  listing: ListingCardData;
  isFavorited?: boolean;
  onToggleFavorite?: (listingId: string) => void;
}

export function ListingCard({ listing, isFavorited, onToggleFavorite }: ListingCardProps) {
  return (
    <Link
      href={`/ilan/${listing.id}`}
      className="group block overflow-hidden rounded-2xl bg-white ring-1 ring-slate-100 transition-all duration-200 hover:ring-slate-200 hover:shadow-lg hover:shadow-slate-200/50"
    >
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100">
        {listing.cover_image_url ? (
          <Image
            src={listing.cover_image_url}
            alt={listing.title}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-slate-300 text-sm">
            Görsel yok
          </div>
        )}

        {listing.is_featured && (
          <span className="absolute left-3 top-3 rounded-full bg-slate-900/90 px-2.5 py-1 text-[11px] font-medium text-white backdrop-blur-sm">
            Vitrin
          </span>
        )}

        {onToggleFavorite && (
          <button
            onClick={(e) => {
              e.preventDefault();
              onToggleFavorite(listing.id);
            }}
            aria-label={isFavorited ? 'Favorilerden çıkar' : 'Favorilere ekle'}
            className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 backdrop-blur-sm transition-colors hover:bg-white"
          >
            <Heart
              className={`h-4 w-4 transition-colors ${
                isFavorited ? 'fill-orange-600 text-orange-600' : 'text-slate-600'
              }`}
            />
          </button>
        )}

        <div className="absolute bottom-3 left-3 rounded-lg bg-white/95 px-3 py-1.5 backdrop-blur-sm shadow-sm">
          <span className="font-mono text-[15px] font-semibold tabular-nums text-slate-900">
            {formatPrice(listing.price, listing.currency)}
          </span>
        </div>
      </div>

      <div className="p-3.5">
        <h3 className="line-clamp-2 text-[14px] font-medium leading-snug text-slate-900 group-hover:text-slate-700">
          {listing.title}
        </h3>
        <div className="mt-2 flex items-center justify-between text-[12px] text-slate-500">
          <span className="flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            {listing.district}, {listing.city}
          </span>
          <span>{formatRelativeTime(listing.created_at)}</span>
        </div>
      </div>
    </Link>
  );
}
