'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { ImagePlus, X } from 'lucide-react';
import { Input, Textarea } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { createClient } from '@/lib/supabase/client';
import { listingSchema, type ListingFormValues } from '@/lib/validations/listing.schema';

interface CategoryOption {
  id: string;
  name: string;
}

interface ListingFormProps {
  categories: CategoryOption[];
  userId: string;
}

const MAX_IMAGES = 8;

export function ListingForm({ categories, userId }: ListingFormProps) {
  const [images, setImages] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const supabase = createClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ListingFormValues>({
    resolver: zodResolver(listingSchema),
  });

  function handleImageSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []).slice(0, MAX_IMAGES - images.length);
    if (files.length === 0) return;

    setImages((prev) => [...prev, ...files]);
    setPreviews((prev) => [...prev, ...files.map((f) => URL.createObjectURL(f))]);
  }

  function removeImage(index: number) {
    setImages((prev) => prev.filter((_, i) => i !== index));
    setPreviews((prev) => prev.filter((_, i) => i !== index));
  }

  async function onSubmit(values: ListingFormValues) {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const { data: listing, error: listingError } = await supabase
        .from('listings')
        .insert({
          user_id: userId,
          category_id: values.category_id,
          title: values.title,
          description: values.description,
          price: values.price,
          city: values.city,
          district: values.district,
          status: 'draft',
        })
        .select('id')
        .single();

      if (listingError || !listing) {
        throw new Error(listingError?.message || 'İlan oluşturulamadı.');
      }

      if (images.length > 0) {
        const uploads = images.map(async (file, index) => {
          const ext = file.name.split('.').pop();
          const path = `${userId}/${listing.id}/${index}-${Date.now()}.${ext}`;

          const { error: uploadError } = await supabase.storage
            .from('listing-images')
            .upload(path, file);

          if (uploadError) throw uploadError;

          return supabase.from('listing_images').insert({
            listing_id: listing.id,
            storage_path: path,
            sort_order: index,
          });
        });

        await Promise.all(uploads);
      }

      const checkoutRes = await fetch('/api/payments/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ listingId: listing.id }),
      });

      const checkoutData = await checkoutRes.json();

      if (!checkoutRes.ok) {
        throw new Error(checkoutData.error || 'Ödeme başlatılamadı.');
      }

      sessionStorage.setItem('iyzico_checkout_content', checkoutData.checkoutFormContent);
      window.location.href = `/ilan/${listing.id}/odeme`;
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Bir şeyler ters gitti.');
      setIsSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">İlan Ver</h1>
        <p className="mt-1 text-sm text-slate-500">
          Bilgileri doldurun, ilan ücreti olan{' '}
          <span className="font-medium text-slate-700">50 ₺</span> ödemesi sonrası ilanınız anında
          yayınlanır.
        </p>
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">
          Fotoğraflar <span className="text-slate-400">({images.length}/{MAX_IMAGES})</span>
        </label>
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
          {previews.map((src, i) => (
            <div key={src} className="relative aspect-square overflow-hidden rounded-lg ring-1 ring-slate-200">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt={`Görsel ${i + 1}`} className="h-full w-full object-cover" />
              <button
                type="button"
                onClick={() => removeImage(i)}
                className="absolute right-1 top-1 rounded-full bg-slate-900/70 p-1 text-white"
                aria-label="Görseli kaldır"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
          {images.length < MAX_IMAGES && (
            <label className="flex aspect-square cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-slate-300 text-slate-400 transition-colors hover:border-slate-400 hover:text-slate-500">
              <ImagePlus className="h-5 w-5" />
              <span className="text-[11px]">Ekle</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={handleImageSelect} />
            </label>
          )}
        </div>
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">Kategori</label>
        <select
          {...register('category_id')}
          className="h-11 w-full rounded-lg border border-slate-200 bg-white px-3.5 text-sm text-slate-900 focus:border-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
        >
          <option value="">Kategori seçin</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        {errors.category_id && <p className="mt-1.5 text-xs text-red-600">{errors.category_id.message}</p>}
      </div>

      <Input
        label="Başlık"
        placeholder="Örn. iPhone 14 Pro 256GB Mavi"
        error={errors.title?.message}
        {...register('title')}
      />

      <Textarea
        label="Açıklama"
        placeholder="Ürün veya hizmet hakkında detaylı bilgi verin..."
        rows={5}
        error={errors.description?.message}
        {...register('description')}
      />

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="Fiyat (₺)"
          type="number"
          inputMode="decimal"
          placeholder="0"
          error={errors.price?.message}
          {...register('price')}
        />
        <Input label="Şehir" placeholder="İstanbul" error={errors.city?.message} {...register('city')} />
      </div>

      <Input label="İlçe" placeholder="Kadıköy" error={errors.district?.message} {...register('district')} />

      {submitError && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{submitError}</div>
      )}

      <Button type="submit" size="lg" className="w-full" isLoading={isSubmitting}>
        {isSubmitting ? 'İlan hazırlanıyor...' : 'İlanı Yayınla · 50 ₺ Öde'}
      </Button>
    </form>
  );
}
