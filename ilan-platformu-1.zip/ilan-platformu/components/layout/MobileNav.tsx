'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, MessageSquare, Plus, Heart, User } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/', icon: Home, label: 'Ana Sayfa' },
  { href: '/favoriler', icon: Heart, label: 'Favoriler' },
  { href: '/ilan/yeni', icon: Plus, label: 'İlan Ver', isPrimary: true },
  { href: '/mesajlar', icon: MessageSquare, label: 'Mesajlar' },
  { href: '/profil/me', icon: User, label: 'Profil' },
];

export function MobileNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 flex items-center justify-between border-t border-slate-100 bg-white px-2 pb-[env(safe-area-inset-bottom)] sm:hidden">
      {navItems.map((item) => {
        const isActive = pathname === item.href;
        const Icon = item.icon;

        if (item.isPrimary) {
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex flex-1 flex-col items-center justify-center py-2"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-orange-600 text-white shadow-sm">
                <Icon className="h-5 w-5" />
              </span>
            </Link>
          );
        }

        return (
          <Link
            key={item.href}
            href={item.href}
            className="flex flex-1 flex-col items-center justify-center gap-0.5 py-2.5"
          >
            <Icon className={cn('h-5 w-5', isActive ? 'text-slate-900' : 'text-slate-400')} />
            <span className={cn('text-[10px]', isActive ? 'font-medium text-slate-900' : 'text-slate-400')}>
              {item.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
