import Link from 'next/link';
import { MessageSquare, Plus, Heart, User } from 'lucide-react';
import { SearchBar } from './SearchBar';
import { Button } from '@/components/ui/Button';

interface HeaderProps {
  isAuthenticated: boolean;
  unreadCount?: number;
}

export function Header({ isAuthenticated, unreadCount = 0 }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Link href="/" className="shrink-0 text-lg font-semibold tracking-tight text-slate-900">
          ilan<span className="text-orange-600">.</span>
        </Link>

        <div className="hidden flex-1 max-w-xl sm:block">
          <SearchBar />
        </div>

        <div className="ml-auto flex items-center gap-1.5">
          {isAuthenticated ? (
            <>
              <Link
                href="/favoriler"
                className="hidden rounded-full p-2.5 text-slate-600 hover:bg-slate-100 sm:block"
                aria-label="Favoriler"
              >
                <Heart className="h-5 w-5" />
              </Link>
              <Link
                href="/mesajlar"
                className="relative hidden rounded-full p-2.5 text-slate-600 hover:bg-slate-100 sm:block"
                aria-label="Mesajlar"
              >
                <MessageSquare className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-orange-600" />
                )}
              </Link>
              <Link href="/profil/me" className="hidden rounded-full p-2.5 text-slate-600 hover:bg-slate-100 sm:block">
                <User className="h-5 w-5" />
              </Link>
              <Link href="/ilan/yeni">
                <Button size="md" className="gap-1.5">
                  <Plus className="h-4 w-4" />
                  <span className="hidden sm:inline">İlan Ver</span>
                </Button>
              </Link>
            </>
          ) : (
            <>
              <Link href="/login">
                <Button variant="ghost" size="md">Giriş Yap</Button>
              </Link>
              <Link href="/register">
                <Button size="md">Üye Ol</Button>
              </Link>
            </>
          )}
        </div>
      </div>

      <div className="border-t border-slate-100 px-4 py-2.5 sm:hidden">
        <SearchBar />
      </div>
    </header>
  );
}
