'use client';

import { useEffect, useRef } from 'react';
import { ArrowLeft, MoreVertical } from 'lucide-react';
import Link from 'next/link';
import { useRealtimeChat } from '@/lib/hooks/useRealtimeChat';
import { ChatBubble } from './ChatBubble';
import { ChatInput } from './ChatInput';
import { TypingIndicator } from './TypingIndicator';

interface ChatWindowProps {
  conversationId: string;
  currentUserId: string;
  otherUser: { name: string; avatarUrl: string | null };
  listing?: { id: string; title: string; price: number } | null;
}

export function ChatWindow({ conversationId, currentUserId, otherUser, listing }: ChatWindowProps) {
  const { messages, loading, otherUserTyping, sendMessage, broadcastTyping } = useRealtimeChat({
    conversationId,
    currentUserId,
  });

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, otherUserTyping]);

  return (
    <div className="flex h-[100dvh] flex-col bg-white sm:h-[calc(100vh-64px)]">
      <div className="flex items-center gap-3 border-b border-slate-100 px-4 py-3">
        <Link href="/mesajlar" className="rounded-full p-1.5 hover:bg-slate-100 sm:hidden">
          <ArrowLeft className="h-5 w-5 text-slate-600" />
        </Link>

        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-sm font-medium text-slate-600">
          {otherUser.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={otherUser.avatarUrl} alt={otherUser.name} className="h-full w-full rounded-full object-cover" />
          ) : (
            otherUser.name.charAt(0).toUpperCase()
          )}
        </div>

        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-slate-900">{otherUser.name}</p>
          {listing && (
            <p className="truncate text-xs text-slate-500">{listing.title}</p>
          )}
        </div>

        <button className="rounded-full p-1.5 hover:bg-slate-100" aria-label="Seçenekler">
          <MoreVertical className="h-5 w-5 text-slate-600" />
        </button>
      </div>

      {listing && (
        <Link
          href={`/ilan/${listing.id}`}
          className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-4 py-2.5 text-sm hover:bg-slate-100"
        >
          <span className="truncate text-slate-700">{listing.title}</span>
          <span className="ml-3 shrink-0 font-mono font-semibold tabular-nums text-slate-900">
            {new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(listing.price)}
          </span>
        </Link>
      )}

      <div className="flex-1 space-y-2 overflow-y-auto px-3 py-4 sm:px-4">
        {loading ? (
          <div className="flex h-full items-center justify-center text-sm text-slate-400">
            Mesajlar yükleniyor...
          </div>
        ) : messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <p className="text-sm font-medium text-slate-600">Henüz mesaj yok</p>
            <p className="mt-1 text-xs text-slate-400">İlk mesajı göndererek sohbete başlayın.</p>
          </div>
        ) : (
          messages.map((msg) => (
            <ChatBubble
              key={msg.id}
              content={msg.content}
              createdAt={msg.created_at}
              isOwn={msg.sender_id === currentUserId}
              isRead={msg.is_read}
            />
          ))
        )}
        {otherUserTyping && <TypingIndicator />}
        <div ref={scrollRef} />
      </div>

      <ChatInput
        onSend={(content) => sendMessage(content)}
        onTyping={broadcastTyping}
        disabled={loading}
      />
    </div>
  );
}
