import Link from 'next/link';
import { MessageSquare } from 'lucide-react';
import { useConversations } from '@/lib/hooks/useConversations';
import { formatRelativeTime } from '@/lib/utils';

interface ConversationListProps {
  currentUserId: string;
  activeConversationId?: string;
}

export function ConversationList({ currentUserId, activeConversationId }: ConversationListProps) {
  const { conversations, loading } = useConversations(currentUserId);

  if (loading) {
    return (
      <div className="space-y-1 p-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-100" />
        ))}
      </div>
    );
  }

  if (conversations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
        <MessageSquare className="h-8 w-8 text-slate-300" />
        <p className="mt-3 text-sm font-medium text-slate-600">Henüz mesajınız yok</p>
        <p className="mt-1 text-xs text-slate-400">Bir ilana mesaj attığınızda burada görünür.</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-slate-100">
      {conversations.map((conv) => (
        <Link
          key={conv.id}
          href={`/mesajlar/${conv.id}`}
          className={`flex items-center gap-3 px-4 py-3.5 transition-colors hover:bg-slate-50 ${
            activeConversationId === conv.id ? 'bg-slate-50' : ''
          }`}
        >
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-medium text-slate-600">
            {conv.other_user_name?.charAt(0).toUpperCase() || '?'}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between">
              <p className="truncate text-sm font-medium text-slate-900">{conv.other_user_name}</p>
              <span className="ml-2 shrink-0 text-[11px] text-slate-400">
                {formatRelativeTime(conv.last_message_at)}
              </span>
            </div>
            <p className="truncate text-xs text-slate-500">{conv.listing_title}</p>
          </div>
          {conv.unread_count > 0 && (
            <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-orange-600 px-1.5 text-[11px] font-medium text-white">
              {conv.unread_count}
            </span>
          )}
        </Link>
      ))}
    </div>
  );
}
