import { formatRelativeTime } from '@/lib/utils';
import { Check, CheckCheck } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChatBubbleProps {
  content: string;
  createdAt: string;
  isOwn: boolean;
  isRead: boolean;
}

export function ChatBubble({ content, createdAt, isOwn, isRead }: ChatBubbleProps) {
  return (
    <div className={cn('flex', isOwn ? 'justify-end' : 'justify-start')}>
      <div
        className={cn(
          'max-w-[78%] rounded-2xl px-3.5 py-2 text-[14px] leading-relaxed',
          isOwn
            ? 'bg-slate-900 text-white rounded-br-md'
            : 'bg-slate-100 text-slate-900 rounded-bl-md'
        )}
      >
        <p className="whitespace-pre-wrap break-words">{content}</p>
        <div
          className={cn(
            'mt-1 flex items-center gap-1 text-[11px]',
            isOwn ? 'text-slate-300 justify-end' : 'text-slate-400'
          )}
        >
          <span>{formatRelativeTime(createdAt)}</span>
          {isOwn && (isRead ? <CheckCheck className="h-3 w-3" /> : <Check className="h-3 w-3" />)}
        </div>
      </div>
    </div>
  );
}
