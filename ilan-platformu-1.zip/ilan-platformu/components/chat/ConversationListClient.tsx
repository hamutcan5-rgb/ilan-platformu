'use client';

import { ConversationList } from './ConversationList';

export function ConversationListClient({ currentUserId }: { currentUserId: string }) {
  return <ConversationList currentUserId={currentUserId} />;
}
